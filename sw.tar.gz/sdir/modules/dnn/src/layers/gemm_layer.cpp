// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html.

#include "../precomp.hpp"
#include "layers_common.hpp"
#include "../net_impl.hpp"
#include "cpu_kernels/fusion_apply.hpp"
// backends
#include "../op_cuda.hpp"
#ifdef HAVE_CUDA
// #include "../cuda4dnn/primitives/matmul.hpp"
#include "../cuda4dnn/primitives/inner_product.hpp"
#include "fusion_cuda.hpp"
using namespace cv::dnn::cuda4dnn;
#endif
#include "../op_cann.hpp"
#include "../ie_ngraph.hpp"
#include "../op_vkcom.hpp"

#include <opencv2/dnn/shape_utils.hpp>
#include "cpu_kernels/fast_gemm.hpp"
#include "cpu_kernels/mlas_gemm.hpp"

namespace cv { namespace dnn {

enum class LayerGemmOpMode {
    blobB,
    blobBC,
    blobC,
    noblob
};

bool constB(LayerGemmOpMode mode){
    switch (mode) {
        case LayerGemmOpMode::blobB:
        case LayerGemmOpMode::blobBC:
            return true;
        default:
            return false;
    }
}

bool constC(LayerGemmOpMode mode){
    switch (mode) {
        case LayerGemmOpMode::blobC:
        case LayerGemmOpMode::blobBC:
            return true;
        default:
            return false;
    }
}


// Y = alpha * A’ * B’ + beta * C
class GemmLayerImpl CV_FINAL : public GemmLayer {
    PreparedFusion fusion;

public:
    mutable int inpType = -1;

    static bool absorbOp(Layer* self, const Ptr<AdjacencyGraph>& expr)
    {
        return static_cast<GemmLayerImpl*>(self)->fusion.take(expr);
    }

    GemmLayerImpl(const LayerParams& params) {
        registerFusionOpsOnce<GemmLayerImpl>({ nullptr, &GemmLayerImpl::absorbOp });
        setParamsFrom(params);

        trans_a = params.get<bool>("transA", false);
        trans_b = params.get<bool>("transB", false);
        alpha = params.get<float>("alpha", 1.0f);
        beta = params.get<float>("beta", 1.0f);
        flatten_a = params.get<bool>("flatten_a", true);

        // The params are not part of ONNX, but set by old ONNX parser
        const_B = params.get<bool>("constB", false);
        const_C = params.get<bool>("constC", false);
        have_bias =  params.get<bool>("have_bias", false);

        real_ndims_C = params.get<int>("real_ndims_C", -1);

        for (Mat& blob : blobs) {
            if (blob.type() == CV_16F || blob.type() == CV_16BF ||
                blob.type() == CV_8F_E4M3FN || blob.type() == CV_8F_E4M3FNUZ) {
                Mat widened;
                blob.convertTo(widened, CV_32F);
                blob = widened;
            }
        }
    }

#ifdef HAVE_CUDA
    // the fused math has a CUDA form to run after the GEMM; N is the GEMM's output width
    bool cudaFusedActivation() const
    {
        return !blobs.empty() && cudaSupportsFusion(fusion, trans_b ? blobs[0].size[0] : blobs[0].size[1]);
    }
#endif

    virtual bool supportBackend(int backendId) CV_OVERRIDE {
#ifdef HAVE_CUDA
        if (fusion.expr && !(backendId == DNN_BACKEND_CUDA && cudaFusedActivation()))
            return backendId == DNN_BACKEND_OPENCV;
        if (backendId == DNN_BACKEND_CUDA) {
            // inpType is set by getTypes() on the first forward; until then use the graph's arg type
            int t = inpType;
            Net::Impl* netimpl_ = getNetImpl(this);
            if (t < 0 && netimpl_ && !inputs.empty())
                t = netimpl_->argData(inputs[0]).type;
            if (!const_B || trans_a || (t >= 0 && t != CV_32F))
                return false;
            // InnerProductOp computes A*B + C: no alpha/beta scaling, and C only as a constant length-N row
            if (alpha != 1.f || inputs.size() > 1)
                return false;
            if (blobs.size() >= 2) {
                const Mat& C = blobs[1];
                const int N = trans_b ? blobs[0].size[0] : blobs[0].size[1];
                if (beta != 1.f || C.dims < 1 || C.total() != (size_t)N || C.size[C.dims - 1] != N)
                    return false;
            }
            return true;
        }
#else
        if (fusion.expr)
            return backendId == DNN_BACKEND_OPENCV;
#endif
        return backendId == DNN_BACKEND_OPENCV ||
               backendId == DNN_BACKEND_CANN ||
               backendId == DNN_BACKEND_INFERENCE_ENGINE_NGRAPH ||
               (backendId == DNN_BACKEND_VKCOM && haveVulkan() && !have_bias && !trans_a);
    }

    virtual void getTypes(const std::vector<MatType>& inputs,
                          const int requiredOutputs,
                          const int requiredInternals,
                          std::vector<MatType>& outputs,
                          std::vector<MatType>& internals) const CV_OVERRIDE
    {
        CV_Assert(inputs.size());
        for (auto input : inputs)
            CV_CheckType(input, input == CV_32F || input == CV_64F, "");

        inpType = inputs[0];
        outputs.assign(requiredOutputs, inputs[0]);
        internals.assign(requiredInternals, inputs[0]);
    }



    LayerGemmOpMode getOpMode(size_t n_inputs, size_t n_blobs) const {
        if (n_blobs == 0) return LayerGemmOpMode::noblob;
        if (n_inputs == 3) return LayerGemmOpMode::noblob ; // if all inputs are given, then no blobs are used
        if (n_inputs == 2) {
            if (have_bias) {
                // check where the input comes from
                if(const_B)
                    return LayerGemmOpMode::blobB;
                if(const_C)
                    return LayerGemmOpMode::blobC;
                return LayerGemmOpMode::blobC;
            } else {
                if (n_blobs == 1)
                    // 2 inputs, no bias => input[1] is B
                    return LayerGemmOpMode::noblob;
                if (n_blobs == 2)
                    return LayerGemmOpMode::blobC;
            }
        }
        if (n_inputs == 1) {
            // only A is given per input
            if (n_blobs == 2)
                return LayerGemmOpMode::blobBC;
            else
                return LayerGemmOpMode::blobB;
        }
        CV_Error(Error::StsError, "DNN/Gemm: could not derive OP mode");
    }


    virtual bool getMemoryShapes(const std::vector<MatShape> &inputs,
                                 const int requiredOutputs,
                                 std::vector<MatShape> &outputs,
                                 std::vector<MatShape> &internals) const CV_OVERRIDE {
        int num_inputs = static_cast<int>(inputs.size() + blobs.size());

        CV_CheckGE(num_inputs, 2, "DNN/Gemm: Gemm takes at least two inputs");
        CV_CheckLE(num_inputs, 3, "DNN/Gemm: Gemm takes at most three inputs");

        LayerGemmOpMode mode = getOpMode(inputs.size(), blobs.size());

        // Check whether A and B are two dimensional
        const auto shape_A = inputs[0];
        const auto shape_B =  constB(mode) ? shape(blobs[0]) : inputs[1];
        // flatten_a=false is only produced by the in-graph MatMul -> Gemm rewrite, and ONNX
        // MatMul does accept a rank-1 A: it is promoted to (1, K) and the leading 1 is
        // squeezed from the result again, so Y is (N,). Handle that as (1, K) here instead of
        // rejecting it; a genuine ONNX Gemm (plain Gemm layer, flatten_a=true) still needs 2D.
        const bool rank1_A = !flatten_a && shape_A.size() == 1;
        CV_Check(shape_A.size(), rank1_A || shape_A.size() >= 2,
                 "DNN/Gemm: Tensor A must be n-dimensional (n >= 2)");
        CV_CheckEQ(shape_B.size(), static_cast<size_t>(2), "DNN/Gemm: Tensor B must be two dimensional");

        // Check legal matrix multiplication
        size_t dims_A = shape_A.size();
        int ma = rank1_A ? 1 : shape_A[dims_A - 2];
        int na = shape_A[dims_A - 1];
        int mb = shape_B[0], nb = shape_B[1];
        int M = trans_a ? na : ma;
        int N = trans_b ? mb : nb;
        int K_a = trans_a ? ma : na;
        int K_b = trans_b ? nb : mb;


        CV_CheckEQ(K_a, K_b, "DNN/Gemm: Invalid dimension of dim K");

        // Check whether C can be unidirectional broadcast to (M, N). Handle carefully with 1D Mat.
        if (have_bias) {
            const auto shape_C = constC(mode) ? shape(blobs.back()) : inputs.back();

            auto ndims_C = shape_C.size();
            CV_CheckLE(ndims_C, static_cast<size_t>(2), "DNN/Gemm: C can only be 0d (scalar) / 1d / 2d tensor");

            int real_ndims_C_ = real_ndims_C >= 0 ? real_ndims_C : ndims_C;

            if (real_ndims_C_ == 1) { // (1,) or (N,)
                CV_Check(shape_C[0], shape_C[0] == 1 || shape_C[0] == N, "DNN/Gemm: invalid dimension of C");
            } else if (real_ndims_C_ == 2) { // (1, 1) or (1, N) or (M, 1) or (M, N)
                // printf("shape_C=[%d, %d]\n", shape_C[0], shape_C[1]);
                CV_Check(shape_C[0], (shape_C[0] == 1 && shape_C[1] == 1) ||
                                     (shape_C[0] == 1 && shape_C[1] == N) ||
                                     (shape_C[0] == M && shape_C[1] == 1) ||
                                     (shape_C[0] == M && shape_C[1] == N),
                                     "DNN/Gemm: C must be of shape (1, 1) or (1, N) or (M, 1) or (M, N)");
                if (shape_C[0] == 1) {
                    CV_Check(shape_C[1], shape_C[1] == 1 || shape_C[1] == N, "DNN/Gemm: invalid dimension of C");
                } else if (shape_C[0] == M) {
                    CV_Check(shape_C[1], shape_C[1] == 1 || shape_C[1] == N, "DNN/Gemm: invalid dimension of C");
                } else {
                    CV_Error(Error::StsBadSize, "DNN/Gemm: invalid dimension of C");
                }
            }
        }

        if (flatten_a) {
            int batches = std::accumulate(shape_A.begin(), shape_A.end() - 2, 1, std::multiplies<int>());
            MatShape shape_y{M * batches, N};
            outputs.assign(1, shape_y);
        } else {
            // Preserve A's leading dims; only the trailing axis changes from K to N.
            // (trans_a is rejected upstream for this mode, so M corresponds to
            //  shape_A[-2] and we just rewrite the last axis.)
            CV_CheckFalse(trans_a, "DNN/Gemm: flatten_a=false requires trans_a=false");
            MatShape shape_y = shape_A;
            shape_y[shape_y.size() - 1] = N;
            outputs.assign(1, shape_y);
        }
        return false;
    }

    virtual int64 getFLOPS(const std::vector<MatShape> &inputs,
                           const std::vector<MatShape> &outputs) const CV_OVERRIDE
    {
        CV_Assert(!inputs.empty());
        LayerGemmOpMode mode_ = getOpMode(inputs.size(), blobs.size());
        const auto shape_A = inputs[0];
        const auto shape_B = constB(mode_) ? shape(blobs[0]) : inputs[1];
        int M = trans_a ? shape_A.back()
                        : (shape_A.size() >= 2 ? shape_A[shape_A.size() - 2] : 1);
        int K = trans_a ? shape_A[shape_A.size() - 2] : shape_A.back();
        int N = trans_b ? shape_B[shape_B.size() - 2] : shape_B.back();

        int64 batches = std::accumulate(shape_A.begin(), shape_A.end() - 2,
                                        CV_BIG_INT(1), std::multiplies<int64>());

        // 2*M*N*K multiply-adds, +M*N for bias
        int64 flops = batches * (CV_BIG_INT(2) * M * N * K);
        if (have_bias)
            flops += batches * M * N;
        return flops;
    }

    // TODO: replace with cv::broadcast() once 1d mat is supported
    // FIXME: fix if conditions if 1d mat is supported properly
    void broadcastCWtihBeta(int M, int N, const Mat &C) {
        broadcast_C.clear();
        broadcast_C.resize(M * N, 0.f);
        if (beta != 0 && !C.empty()) {
            int real_ndims_C_ = real_ndims_C >= 0 ? real_ndims_C : C.dims;

            const float *ptr_c = C.ptr<const float>();
            const auto shape_C = shape(C);
            if ((real_ndims_C_ == 0) || (real_ndims_C_ == 1 && shape_C[0] == 1) ||
                (real_ndims_C_ == 2 && shape_C[0] == 1 && shape_C[1] == 1)) {
                // (), (1,), (1, 1)
                float c = *ptr_c;
                int total = M * N;
                for (int i = 0; i < total; ++i) {
                    broadcast_C[i] = beta * c;
                }
            } else if ((real_ndims_C_ == 1 && shape_C[0] == N) ||
                       (real_ndims_C_ == 2 && shape_C[0] == 1 && shape_C[1] == N)) {
                // (N,), (1, N)
                for (int i = 0; i < M; ++i) {
                    int step = i * N;
                    for (int j = 0; j < N; ++j) {
                        broadcast_C[step + j] = beta * ptr_c[j];
                    }
                }
            } else if (real_ndims_C_ == 2 && shape_C[0] == M && shape_C[1] == 1) {
                // (M, 1)
                for (int i = 0; i < M; ++i) {
                    int step = i * N;
                    for (int j = 0; j < N; ++j) {
                        broadcast_C[step + j] = beta * ptr_c[i];
                    }
                }
            } else {
                // (M, N)
                std::transform(ptr_c, ptr_c + M * N, broadcast_C.begin(), [this] (const float &c) {
                    return this->beta * c; });
            }
        }
    }



    virtual void finalize(InputArrayOfArrays inputs_arr, OutputArrayOfArrays outputs_arr) CV_OVERRIDE {
        opt.init();
        std::vector<Mat> inputs;
        inputs_arr.getMatVector(inputs);

        // CV_64F skips the float-only packed-B/MLAS caching below; see forwardDouble().
        if (inputs[0].depth() == CV_64F)
            return;

        LayerGemmOpMode mode = getOpMode(inputs.size(), blobs.size());

        // pack B if it is const
        if (constB(mode) && blobs[0].data != last_packed_blob_data) {
            packed_B.clear();
            packed_B.shrink_to_fit();
            thin_packed_B.clear();
            thin_packed_B.shrink_to_fit();

            bool mlas_packed = false;
#ifdef HAVE_MLAS
            packed_B_mlas.release();
            packed_B_mlas_M = packed_B_mlas_N = packed_B_mlas_K = 0;
            if (mlasAvailable() && !opt.use_rvv) {
                std::vector<Mat> outputs;
                outputs_arr.getMatVector(outputs);
                const auto shape_A = shape(inputs[0]);
                const auto shape_Y = shape(outputs[0]);
                const int na = shape_A[shape_A.size() - 1];
                const int N  = shape_Y[shape_Y.size() - 1];
                // rank-1 A / (N,) Y of the MatMul rewrite: M == 1 (see getMemoryShapes())
                const int ma = shape_A.size() >= 2 ? shape_A[shape_A.size() - 2] : 1;
                const int M  = shape_Y.size() >= 2 ? shape_Y[shape_Y.size() - 2] : 1;
                const int K  = trans_a ? ma : na;
                const Mat& Bmat = blobs[0];
                const int ldb = Bmat.size[Bmat.dims - 1];
                const size_t packed_bytes = mlasSgemmPackBSize(trans_a, trans_b, N, K);
                if (packed_bytes > 0 && packed_bytes <= static_cast<size_t>(INT_MAX)) {
                    packed_B_mlas.create(1, static_cast<int>(packed_bytes), CV_8U);
                    if (mlasSgemmPackB(trans_a, trans_b, N, K,
                                       Bmat.ptr<const float>(), ldb,
                                       packed_B_mlas.data)) {
                        packed_B_mlas_M = M;
                        packed_B_mlas_N = N;
                        packed_B_mlas_K = K;
                        mlas_packed = true;
                    } else {
                        packed_B_mlas.release();
                    }
                }
            }
#endif
            if (!mlas_packed) {
                fastGemmPackB(blobs[0], packed_B, trans_b, opt);

                if (!trans_a && blobs[0].type() == CV_32F) {
                    std::vector<Mat> outputs;
                    outputs_arr.getMatVector(outputs);
                    if (!outputs.empty()) {
                        const auto &Y = outputs[0];
                        const auto shape_Y = shape(Y);
                        const int N = shape_Y.back();
                        const int K = trans_b ? blobs[0].size[1] : blobs[0].size[0];
                        const int rows_thin = flatten_a ? shape_Y[shape_Y.size() - 2]
                                                        : (int)(Y.total() / (size_t)N);
                        if (fastGemmThinEligible(rows_thin, N, K)) {
                            thin_packed_B.resize(fastGemmThinPackBSize(N, K));
                            const size_t ldb_K = trans_b ? 1 : N;
                            const size_t ldb_N = trans_b ? K : 1;
                            fastGemmThinPackB(N, K, blobs[0].ptr<const float>(),
                                              ldb_K, ldb_N, thin_packed_B.data());
                        }
                    }
                }
            }

            last_packed_blob_data = blobs[0].data;
        }

        if (constC(mode) && flatten_a) {
            const auto &C = blobs.back();

            std::vector<Mat> outputs;
            outputs_arr.getMatVector(outputs);
            const auto &Y = outputs[0];
            const auto shape_Y = shape(Y);
            size_t dims_Y = shape_Y.size();
            int M = shape_Y[dims_Y - 2], N = shape_Y[dims_Y - 1];

            // broadcast
            broadcastCWtihBeta(M, N, C);
        }
    }

    // Y = A * B + C, note that C is unidirectionaly broadcastable to (A * B).
    void forward(InputArrayOfArrays inputs_arr, OutputArrayOfArrays outputs_arr, OutputArrayOfArrays internals_arr) CV_OVERRIDE {
        CV_TRACE_FUNCTION();
        CV_TRACE_ARG_VALUE(name, "name", name.c_str());

        if (inputs_arr.depth() == CV_16F)
        {
            forward_fallback(inputs_arr, outputs_arr, internals_arr);
            if (fusion.expr) {
                std::vector<Mat> outs;
                outputs_arr.getMatVector(outs);
                if (!outs.empty()) {
                    Mat y32;
                    outs[0].convertTo(y32, CV_32F);
                    fusion.run(y32);
                    y32.convertTo(outs[0], outs[0].type());
                }
            }
            return;
        }

        std::vector<Mat> inputs, outputs;
        inputs_arr.getMatVector(inputs);
        outputs_arr.getMatVector(outputs);

        LayerGemmOpMode mode = getOpMode(inputs.size(), blobs.size());

        if (inputs[0].depth() == CV_64F) {
            forwardDouble(inputs, outputs, mode);
            return;
        }

        const auto &A = inputs[0];
        auto &Y = outputs[0];

        const auto shape_A = shape(A), shape_Y = shape(Y);
        size_t dims_A = shape_A.size();
        // rank-1 A / (N,) Y: the MatMul rewrite promotes A to (1, K) and squeezes the leading 1
        // from the result, so the single row / single dimension stands for M == 1.
        int ma = dims_A >= 2 ? shape_A[dims_A - 2] : 1;
        int na = shape_A[dims_A - 1];
        size_t dims_Y = shape_Y.size();
        int M = dims_Y >= 2 ? shape_Y[dims_Y - 2] : 1;
        int N = shape_Y[dims_Y - 1];
        int K = trans_a ? ma : na;

        // In flatten_a=false mode the output keeps A's leading dims, so the
        // GEMM row count spans those dims as well: rows = total(Y)/N.
        const int rows = flatten_a ? M : (int)(Y.total() / (size_t)N);

        // broadcast C and copy C to output
        if (constC(mode) || inputs.size() >= 3) {
            float *ptr_y = Y.ptr<float>();
            if (flatten_a) {
                if (!constC(mode) || broadcast_C.empty()) {
                    broadcastCWtihBeta(M, N, (inputs.size() >= 3 ? inputs.back() : blobs.back()));
                }
                int step = M * N;
                CV_CheckEQ(broadcast_C.size(), static_cast<size_t>(step), "DNN/Gemm: C is not broadcast properly");
                const float* src = broadcast_C.data();
                constexpr size_t PAR_THRESHOLD = 1u << 14;
                if ((size_t)step < PAR_THRESHOLD) {
                    std::memcpy(ptr_y, src, (size_t)step * sizeof(float));
                } else {
                    int nthreads = std::max(1, getNumThreads());
                    parallel_for_(Range(0, nthreads), [=](const Range& r) {
                        size_t st = (size_t)r.start * (size_t)step / (size_t)nthreads;
                        size_t en = (size_t)r.end   * (size_t)step / (size_t)nthreads;
                        std::memcpy(ptr_y + st, src + st, (en - st) * sizeof(float));
                    }, nthreads);
                }
            } else {
                // ND output: tile the (1D / scalar) bias across all `rows`
                // rows, scaled by beta. The rewriter restricts bias to scalar
                // or 1D length-N; assert here.
                const Mat& C = (inputs.size() >= 3) ? inputs.back() : blobs.back();
                const float* c = C.ptr<const float>();
                if (C.total() == 1) {
                    float val = beta * (*c);
                    size_t total = (size_t)rows * (size_t)N;
                    constexpr size_t PAR_THRESHOLD = 1u << 14;
                    if (total < PAR_THRESHOLD) {
                        std::fill_n(ptr_y, total, val);
                    } else {
                        int nthreads = std::max(1, getNumThreads());
                        parallel_for_(Range(0, nthreads), [=](const Range& r) {
                            size_t st = (size_t)r.start * total / (size_t)nthreads;
                            size_t en = (size_t)r.end   * total / (size_t)nthreads;
                            std::fill_n(ptr_y + st, en - st, val);
                        }, nthreads);
                    }
                } else {
                    CV_CheckEQ((int)C.total(), N, "DNN/Gemm: bias must be scalar or length-N in flatten_a=false mode");
                    // Compute first row, then broadcast.
                    for (int j = 0; j < N; j++) ptr_y[j] = beta * c[j];
                    if (rows > 1) {
                        size_t row_bytes = (size_t)N * sizeof(float);
                        constexpr int PAR_THRESHOLD_ROWS = 32;
                        if (rows <= PAR_THRESHOLD_ROWS) {
                            for (int i = 1; i < rows; i++) {
                                std::memcpy(ptr_y + (size_t)i * N, ptr_y, row_bytes);
                            }
                        } else {
                            int nthreads = std::max(1, getNumThreads());
                            double nstripes = std::min((double)(rows - 1), (double)nthreads);
                            parallel_for_(Range(1, rows), [=](const Range& r) {
                                for (int i = r.start; i < r.end; i++) {
                                    std::memcpy(ptr_y + (size_t)i * N, ptr_y, row_bytes);
                                }
                            }, nstripes);
                        }
                    }
                }
            }
        } else { // initialization
            float *ptr_y = Y.ptr<float>();
            size_t total = Y.total();
            constexpr size_t PAR_THRESHOLD = 1u << 14;
            if (total < PAR_THRESHOLD) {
                std::memset(ptr_y, 0, total * sizeof(float));
            } else {
                int nthreads = std::max(1, getNumThreads());
                parallel_for_(Range(0, nthreads), [=](const Range& r) {
                    size_t st = (size_t)r.start * total / (size_t)nthreads;
                    size_t en = (size_t)r.end   * total / (size_t)nthreads;
                    std::memset(ptr_y + st, 0, (en - st) * sizeof(float));
                }, nthreads);
            }
        }

        if (constB(mode)) {
#ifdef HAVE_MLAS
            if (!opt.use_rvv && !packed_B_mlas.empty() &&
                packed_B_mlas_N == N && packed_B_mlas_K == K)
            {
                if (mlasSgemmPacked(trans_a, trans_b, rows, N, K,
                                    alpha,
                                    A.ptr<const float>(), na,
                                    packed_B_mlas.data,
                                    1.f,
                                    Y.ptr<float>(), N)) {
                    fusion.run(Y);
                    return;
                }
            }
#endif
            CV_CheckGT(packed_B.size(), static_cast<size_t>(0), "DNN/Gemm: constant B is not pre-packed");
            if (!thin_packed_B.empty()) {
                fastGemmThin(rows, N, K, alpha, A.ptr<const float>(), na, 1,
                             thin_packed_B.data(), 1.f, Y.ptr<float>(), N, opt.multi_thread);
            } else {
                fastGemm(trans_a, rows, N, K, alpha, A.ptr<const float>(), na, packed_B.data(), 1.f, Y.ptr<float>(), N, opt);
            }
        } else {
            fastGemmBatch(trans_a, trans_b, alpha, A, inputs[1], 1.f, Y, opt);
        }
        fusion.run(Y);
    }

    // Double-precision analogue of broadcastCWtihBeta() above; not cached (see finalize()).
    static void fillBroadcastCDouble(int M, int N, const Mat& C, double beta, Mat& dst)
    {
        CV_Assert(dst.rows == M && dst.cols == N);
        double* out = dst.ptr<double>();
        size_t total = (size_t)M * (size_t)N;

        if (beta == 0 || C.empty()) {
            std::fill_n(out, total, 0.0);
            return;
        }

        const double* c = C.ptr<const double>();
        const auto shape_C = shape(C);
        int ndims_C = (int)shape_C.size();

        if (ndims_C == 0 || (ndims_C == 1 && shape_C[0] == 1) ||
            (ndims_C == 2 && shape_C[0] == 1 && shape_C[1] == 1)) {
            // (), (1,), (1, 1): single scalar broadcast to every element.
            std::fill_n(out, total, beta * c[0]);
        } else if ((ndims_C == 1 && shape_C[0] == N) ||
                   (ndims_C == 2 && shape_C[0] == 1 && shape_C[1] == N)) {
            // (N,), (1, N): one row broadcast down every row.
            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                    out[(size_t)i * N + j] = beta * c[j];
        } else if (ndims_C == 2 && shape_C[0] == M && shape_C[1] == 1) {
            // (M, 1): one value per row broadcast across every column.
            for (int i = 0; i < M; i++)
                std::fill_n(out + (size_t)i * N, N, beta * c[i]);
        } else {
            // (M, N): no broadcast, just scale.
            CV_CheckEQ(shape_C[0], M, "DNN/Gemm: C is not broadcast properly");
            CV_CheckEQ(shape_C[1], N, "DNN/Gemm: C is not broadcast properly");
            for (size_t i = 0; i < total; i++)
                out[i] = beta * c[i];
        }
    }

    // CV_64F via cv::gemm, not the float-only fastGemm/MLAS kernels above.
    void forwardDouble(const std::vector<Mat>& inputs, std::vector<Mat>& outputs, LayerGemmOpMode mode)
    {
        const Mat &A = inputs[0];
        Mat &Y = outputs[0];
        const Mat &B = constB(mode) ? blobs[0] : inputs[1];

        CV_CheckTypeEQ(B.depth(), CV_64F, "DNN/Gemm: B must be CV_64F to match A");
        CV_Assert(A.isContinuous() && Y.isContinuous());

        const auto shape_A = shape(A), shape_Y = shape(Y);
        size_t dims_A = shape_A.size();
        int na = shape_A[dims_A - 1];
        size_t dims_Y = shape_Y.size();
        int N = shape_Y[dims_Y - 1];
        const int rows = (int)(Y.total() / (size_t)N);

        // 2D views onto existing data, no copy; trans_a/trans_b via cv::gemm's own flags.
        Mat Aview = A.reshape(1, (int)(A.total() / (size_t)na));
        Mat Yview = Y.reshape(1, rows);
        const int flags = (trans_a ? GEMM_1_T : 0) | (trans_b ? GEMM_2_T : 0);

        const bool haveC = constC(mode) || inputs.size() >= 3;
        if (haveC) {
            const Mat& C = (inputs.size() >= 3) ? inputs.back() : blobs.back();
            CV_CheckTypeEQ(C.depth(), CV_64F, "DNN/Gemm: C must be CV_64F to match A");
            fillBroadcastCDouble(rows, N, C, (double)beta, Yview);
            cv::gemm(Aview, B, (double)alpha, Yview, 1.0, Yview, flags);
        } else {
            cv::gemm(Aview, B, (double)alpha, Mat(), 0.0, Yview, flags);
        }
    }

#ifdef HAVE_CUDA
    // Y = A * B + C. B should be guaranteed as two dimensional.
    Ptr<BackendNode> initCUDA(void *context_,
                              InputArrayOfArrays inputs_,
                              InputArrayOfArrays outputs) CV_OVERRIDE {
        CV_CheckFalse(trans_a, "DNN/Gemm/Cuda: does not support transA");
        CV_CheckTrue(const_B, "DNN/Gemm/Cuda: input B (weight) is required to be constant");
        auto context = reinterpret_cast<csl::CSLContext*>(context_);
        std::vector<UMat> inputs;
        inputs_.getUMatVector(inputs);
        auto B = blobs[0];
        // with B constant, a second blob is the constant C; the graph rewrites do not set const_C
        auto C = blobs.size() >= 2 ? blobs[1] : Mat();

        if (!trans_b)
            cv::transpose(B, B);
        // flatten_a=false keeps A's leading dims as rows, as forward() does: only the last axis is K
        auto flatten_start_axis = flatten_a ? normalize_axis(1, inputs[0].dims) : inputs[0].dims - 1;
        // the fused activation runs on the same stream, right after the GEMM
        csl::Stream stream = context->stream;
        Ptr<BackendNode> gemmNode = make_cuda_node<cuda4dnn::InnerProductOp>(preferableTarget, std::move(context->stream), std::move(context->cublas_handle), flatten_start_axis, B, C);
        return makeFusedCudaNode(fusion, gemmNode, preferableTarget, stream, outputs.shape(0));
    }
#endif // HAVE_CUDA

#ifdef HAVE_CANN
    // Y = A * B + C.
    virtual Ptr<BackendNode> initCann(const std::vector<Ptr<BackendWrapper> > &inputs,
                                      const std::vector<Ptr<BackendWrapper> > &outputs,
                                      const std::vector<Ptr<BackendNode> >& nodes) CV_OVERRIDE {
        auto x1 = inputs[0].dynamicCast<CannBackendWrapper>();
        auto desc_x1 = x1->getTensorDesc();
        auto op_x1 = nodes[0].dynamicCast<CannBackendNode>()->getOp();

        auto op = std::make_shared<ge::op::MatMulV2>(name);

        // set attributes
        op->set_attr_transpose_x1(trans_a);
        op->set_attr_transpose_x2(trans_b);

        // set inputs
        // set inputs : x1
        op->set_input_x1_by_name(*op_x1, x1->name.c_str());
        op->update_input_desc_x1(*desc_x1);
        // set inputs : x2
        if (const_B) {
            auto B = blobs[0];
            auto op_const_B = std::make_shared<CannConstOp>(B.data, B.type(), shape(B), cv::format("%s_w", name.c_str()));
            op->set_input_x2_by_name(*(op_const_B->getOp()), "y");
            op->update_input_desc_x2(*(op_const_B->getTensorDesc()));
        } else {
            CV_CheckGE(inputs.size(), static_cast<size_t>(2), "DNN/Gemm/CANN: input B is required since it is not constant");
            CV_CheckGE(nodes.size(), static_cast<size_t>(2), "DNN/Gemm/CANN: input B is required since it is not constant");
            auto op_x2 = nodes[1].dynamicCast<CannBackendNode>()->getOp();
            auto desc_x2 = inputs[1].dynamicCast<CannBackendWrapper>()->getTensorDesc();
            op->set_input_x2_by_name(*op_x2, "y");
            op->update_input_desc_x2(*desc_x2);
        }
        // set inputs : bias
        // TODO: clearify if the bias needs to be constant here
        auto mat_C = have_bias && const_C ? blobs.back() : Mat::zeros(1, 1, CV_32F);
        auto shape_C = shape(mat_C);
        if (real_ndims_C == 1) {
            int dim = static_cast<int>(mat_C.total());
            shape_C = std::vector<int>{dim};
        }
        auto op_const_C = std::make_shared<CannConstOp>(mat_C.data, mat_C.type(), shape_C, cv::format("%s_b", name.c_str()));
        op->set_input_bias(*(op_const_C->getOp()));
        op->update_input_desc_bias(*(op_const_C->getTensorDesc()));

        // set outputs
        auto output_desc = std::make_shared<ge::TensorDesc>(ge::Shape(), ge::FORMAT_NCHW, ge::DT_FLOAT);
        op->update_output_desc_y(*output_desc);
        return Ptr<BackendNode>(new CannBackendNode(op));
    }
#endif // HAVE_CANN

#ifdef HAVE_DNN_NGRAPH
    virtual Ptr<BackendNode> initNgraph(const std::vector<Ptr<BackendWrapper> >& inputs,
                                        const std::vector<Ptr<BackendNode> >& nodes) CV_OVERRIDE
    {
        ov::Output<ov::Node> nodeA = nodes[0].dynamicCast<InfEngineNgraphNode>()->node;
        ov::Output<ov::Node> nodeB;
        if (const_B)
            nodeB = std::make_shared<ov::op::v0::Constant>(ov::element::f32, getShape(blobs[0]), blobs[0].data);
        else
            nodeB = nodes[1].dynamicCast<InfEngineNgraphNode>()->node;

        int flatten_axis = nodeA.get_shape().size() - nodeB.get_shape().size();
        if (flatten_axis > 0) {
            std::vector<int> shape(1 + flatten_axis, 0);
            shape[shape.size() - 1] = -1;
            nodeA = std::make_shared<ov::op::v1::Reshape>(
                nodeA,
                std::make_shared<ov::op::v0::Constant>(ov::element::i32, ov::Shape{shape.size()}, shape.data()),
                true);
        }

        std::shared_ptr<ov::Node> nodeAB = std::make_shared<ov::op::v0::MatMul>(nodeA, nodeB, trans_a, trans_b);
        if (alpha != 1.0f)
        {
            nodeAB = std::make_shared<ov::op::v1::Multiply>(
                nodeAB,
                std::make_shared<ov::op::v0::Constant>(ov::element::f32, ov::Shape{1}, &alpha));
        }

        if (!have_bias)
            return Ptr<BackendNode>(new InfEngineNgraphNode(nodeAB));

        ov::Output<ov::Node> nodeC;
        if (const_C)
        {
            auto shape_C = blobs.back().total() == blobs.back().size[0] ? ov::Shape{blobs.back().total()} : getShape(blobs.back());
            nodeC = std::make_shared<ov::op::v0::Constant>(ov::element::f32, shape_C, blobs.back().data);
        }
        else
        {
            nodeC = nodes.back().dynamicCast<InfEngineNgraphNode>()->node;
        }

        if (beta != 1.0f)
        {
            nodeC = std::make_shared<ov::op::v1::Multiply>(
                nodeC,
                std::make_shared<ov::op::v0::Constant>(ov::element::f32, ov::Shape{1}, &beta));
        }

        auto nodeGemm = std::make_shared<ov::op::v1::Add>(nodeAB, nodeC, ov::op::AutoBroadcastType::NUMPY);
        return Ptr<BackendNode>(new InfEngineNgraphNode(nodeGemm));
    }
#endif // HAVE_DNN_NGRAPH

#ifdef HAVE_VULKAN
    // Y = A * B + C. Currently support 2d matrix multiplication without bias.
    virtual Ptr<BackendNode> initVkCom(const std::vector<Ptr<BackendWrapper> > &inputs,
                                       std::vector<Ptr<BackendWrapper> > &outputs) CV_OVERRIDE
    {
        // does not support with bias; only 2d matmul
        auto wrapper_Y = outputs[0].dynamicCast<VkComBackendWrapper>();
        auto shape_Y = shape(*(wrapper_Y->getMat()));
        if (have_bias || shape_Y.size() > static_cast<size_t>(2)) {
            return Ptr<BackendNode>();
        }

        std::vector<Mat> vkBlobs;
        if (const_B) {
            vkBlobs.push_back(blobs[0]);
        }

        auto wrapper_A = inputs[0].dynamicCast<VkComBackendWrapper>();
        auto shape_A = shape(*wrapper_A->getMat());
        Ptr<vkcom::OpBase> op = (new vkcom::OpMatMul(vkBlobs, shape_A[0], shape_A[1], shape_Y[1]));
        return Ptr<BackendNode>(new VkComBackendNode(inputs, op, outputs));
    }
#endif



private:
    bool const_B;
    bool const_C;
    bool have_bias;
    std::vector<float> packed_B;
    std::vector<float> thin_packed_B;
#ifdef HAVE_MLAS
    cv::Mat packed_B_mlas;
    int packed_B_mlas_M = 0;
    int packed_B_mlas_N = 0;
    int packed_B_mlas_K = 0;
#endif
    std::vector<float> broadcast_C;
    int real_ndims_C;
    FastGemmOpt opt;
    const uchar* last_packed_blob_data = nullptr;
};

Ptr<GemmLayer> GemmLayer::create(const LayerParams& params) {
    return makePtr<GemmLayerImpl>(params);
}

}} // namespace cv::dnn
