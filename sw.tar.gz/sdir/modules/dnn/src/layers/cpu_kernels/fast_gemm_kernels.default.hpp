// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html.

// This file is modified from the ficus (https://github.com/vpisarev/ficus/blob/master/runtime/ficus/impl/gemm.impl.h).
// Here is the original license:
/*
    This file is a part of ficus language project.
    See ficus/LICENSE for the licensing terms
*/

#include <opencv2/core/hal/intrin.hpp>
#include <opencv2/core/utility.hpp> // parallel_for_

#define FAST_GEMM_STORAGE (1<<20) // 2^20
#define FAST_GEMM_MAX_STACKBUF (1 << 13)

#define FAST_GEMM_F32_MC 64
#define FAST_GEMM_F32_NC 240
#define FAST_GEMM_F32_MR 8
#define FAST_GEMM_F32_NR 12
#define FAST_GEMM_F32_PACKED_STRIDE_K 64

#define FAST_GEMM_IMPLEMENT_PACK(N, suffix, styp, dtyp) \
static void fast_gemm_pack##N##suffix( int m, int k, const void* A_, \
                                      int lda0, int lda1, void* packA_ ) \
{ \
    const styp* A = (const styp*)A_; \
    dtyp* packA = (dtyp*)packA_; \
    for( int i = 0; i < m; i += N ) { \
        if (i + N-1 < m) { \
            const styp* a_ptr = A + lda0*i; \
            for( int j = 0; j < k*lda1; packA += N, j += lda1 ) \
            { \
                FAST_GEMM_LOAD_TO_BUF_##N(styp); \
                FAST_GEMM_PACK##suffix##_##N(buf, packA); \
            } \
        } else { \
            const styp* a_ptr[N]; \
            for (int k = 0; k < N; k++) a_ptr[k] = A + lda0*(i+k < m ? i+k : i); \
            for( int j = 0; j < k*lda1; packA += N, j += lda1 ) \
            { \
                FAST_GEMM_LOAD_TO_BUF_BORDERS_##N(styp); \
                FAST_GEMM_PACK##suffix##_##N(buf, packA); \
            } \
        } \
    } \
}

#define FAST_GEMM_LOAD_TO_BUF_8(styp) \
    styp buf[] = { \
        a_ptr[j], a_ptr[j+lda0], a_ptr[j+lda0*2], a_ptr[j+lda0*3], \
        a_ptr[j+lda0*4], a_ptr[j+lda0*5], a_ptr[j+lda0*6], a_ptr[j+lda0*7] }

#define FAST_GEMM_LOAD_TO_BUF_BORDERS_8(styp) \
    styp buf[] = { \
        a_ptr[0][j], a_ptr[1][j], a_ptr[2][j], a_ptr[3][j], \
        a_ptr[4][j], a_ptr[5][j], a_ptr[6][j], a_ptr[7][j] }

#define FAST_GEMM_LOAD_TO_BUF_12(styp) \
    styp buf[] = { \
        a_ptr[j], a_ptr[j+lda0], a_ptr[j+lda0*2], a_ptr[j+lda0*3], \
        a_ptr[j+lda0*4], a_ptr[j+lda0*5], a_ptr[j+lda0*6], a_ptr[j+lda0*7], \
        a_ptr[j+lda0*8], a_ptr[j+lda0*9], a_ptr[j+lda0*10], a_ptr[j+lda0*11] }

#define FAST_GEMM_LOAD_TO_BUF_BORDERS_12(styp) \
    styp buf[] = { \
        a_ptr[0][j], a_ptr[1][j], a_ptr[2][j], a_ptr[3][j], \
        a_ptr[4][j], a_ptr[5][j], a_ptr[6][j], a_ptr[7][j], \
        a_ptr[8][j], a_ptr[9][j], a_ptr[10][j], a_ptr[11][j] }

#define FAST_GEMM_PACK_COPY(src, dst, N) \
    memcpy((dst), (src), N*sizeof(src[0]))
#define FAST_GEMM_PACK_f32_8(src, dst) FAST_GEMM_PACK_COPY((src), (dst), 8)
#define FAST_GEMM_PACK_f32_12(src, dst) FAST_GEMM_PACK_COPY((src), (dst), 12)

namespace cv { namespace dnn { namespace cpu_baseline {

size_t fastGemmPackBSize(int N, int K);

int fastGemmMC();
int fastGemmNC();
int fastGemmKC();

void fastGemmPackBKernel(const char *B, char *packed_B, size_t N, size_t K, size_t ldb0, size_t ldb1, size_t esz);

void fastGemmKernel(size_t M, size_t N, size_t K,
                    float alpha, const char *A, size_t lda0, size_t lda1,
                    const char *B, size_t ldb0, size_t ldb1,
                    float beta, char *C, size_t ldc, size_t esz, bool multi_thread);
void fastGemmKernel(size_t M, size_t N, size_t K,
                    float alpha, const char *A, size_t lda0, size_t lda1,
                    const char *packed_B, float beta, char *C, size_t ldc, size_t esz, bool multi_thread);

void fastGemmBatchKernel(size_t batch, const size_t *A_offsets, const size_t *B_offsets, const size_t *C_offsets,
                         size_t M, size_t N, size_t K, float alpha, const char *A, size_t lda0, size_t lda1,
                         const char *B, size_t ldb0, size_t ldb1, float beta, char *C, size_t ldc, size_t esz);
void fastGemmBatchKernel(size_t batch, const size_t *A_offsets, const size_t *B_offsets, const size_t *C_offsets,
                         size_t M, size_t N, size_t K, float alpha, const char *A, size_t lda0, size_t lda1,
                         const char *packed_B, float beta, char *C, size_t ldc, size_t esz);
void pagedAttnAVGemmKernel(
    const char* A, const std::vector<const char *> &V, char*Out,
    size_t B, size_t T_a, size_t Nq, size_t N_k, size_t T_s, size_t D, size_t T_v,
    size_t esz, bool canonical_layout, size_t packed_stride
);
void pagedAttnQKGemmKernel(
    const char *Q, const std::vector<const char *> &K, char *A,
    size_t B, size_t T_q, size_t Nq, size_t N_k, size_t T_s, size_t D, size_t T_k,
    float sm_scale, size_t esz, bool isQ3d
);
FAST_GEMM_IMPLEMENT_PACK(8, _f32, float, float)
FAST_GEMM_IMPLEMENT_PACK(12, _f32, float, float)

size_t fastGemmPackBSize(int N, int K) {
    size_t GEMM_NC = FAST_GEMM_F32_NC, GEMM_NR = FAST_GEMM_F32_NR;
    size_t NC = (((GEMM_NC < N ? GEMM_NC : N) + GEMM_NR - 1) / GEMM_NR) * GEMM_NR;

    return static_cast<size_t>((N + NC - 1) / NC) * NC * K;
}

int fastGemmMC() {
    return FAST_GEMM_F32_MC;
}

int fastGemmNC() {
    return FAST_GEMM_F32_NC;
}

int fastGemmKC() {
    return FAST_GEMM_F32_PACKED_STRIDE_K;
}

int fastGemmNR() {
    return FAST_GEMM_F32_NR;
}

void fastGemmPackBKernel(const char *B, char *packed_B, size_t N, size_t K, size_t ldb0, size_t ldb1, size_t esz) {
    size_t GEMM_NC = FAST_GEMM_F32_NC, GEMM_NR = FAST_GEMM_F32_NR;
    size_t NC = (((GEMM_NC < N ? GEMM_NC : N) + GEMM_NR - 1) / GEMM_NR) * GEMM_NR;
    size_t KC = std::min(static_cast<size_t>(FAST_GEMM_F32_PACKED_STRIDE_K), K);

    size_t n_tiles = (N + NC - 1) / NC;
    for (size_t r = 0; r < n_tiles; ++r) {
        size_t j0 = r * NC;
        size_t nc = N - j0 < NC ? N - j0 : NC;
        size_t _nc = (nc + GEMM_NR - 1) / GEMM_NR * GEMM_NR * esz;
        for (size_t k = 0; k < K; k += KC) {
            size_t kc = K - k < KC ? K - k : KC;
            fast_gemm_pack12_f32(nc, kc, B + (k * ldb0 + j0 * ldb1) * esz, ldb1, ldb0, packed_B);
            packed_B += _nc * kc;
        }
    }
}

static inline void fast_gemm_f32(int k, const char *a_, const char *b_,
                                 char *c_, int ldc, float alpha) {
    const float* a = (const float*)a_;
    const float* b = (const float*)b_;
    float* c = (float*)c_;

    float sbuf[FAST_GEMM_F32_MR * FAST_GEMM_F32_NR];
    memset(sbuf, 0, sizeof(sbuf));
    for(int p = 0; p < k; p++) {
        for( int i = 0; i < FAST_GEMM_F32_MR; i++ ) {
            float ai = a[FAST_GEMM_F32_MR * p + i];
            for( int j = 0; j < FAST_GEMM_F32_NR; j++ )
                sbuf[i * FAST_GEMM_F32_NR + j] += b[FAST_GEMM_F32_NR * p + j] * ai;
        }
    }
    for (int i = 0; i < FAST_GEMM_F32_MR; i++) {
        for (int j = 0; j < FAST_GEMM_F32_NR; j++)
            c[i * ldc + j] += alpha * sbuf[i * FAST_GEMM_F32_NR + j];
    }
}

static void fast_gemm_macro_kernel(int m, int n, int k,
                                   const char *packed_A, const char *packed_B,
                                   float alpha, char *c, int ldc0, int esz) {
    int ldc0_esz = ldc0 * esz;

    double tempC[FAST_GEMM_F32_MR * FAST_GEMM_F32_NR]; // make sure the buffer is big enough
    for(int i = 0; i < m; i += FAST_GEMM_F32_MR) {
        for(int j = 0; j < n; j += FAST_GEMM_F32_NR) {
            char* cptr0 = &c[i * ldc0_esz + j * esz];
            char* cptr = cptr0;
            int ldc = ldc0;
            int mr = m - i < FAST_GEMM_F32_MR ? m - i : FAST_GEMM_F32_MR;
            int nr = n - j < FAST_GEMM_F32_NR ? n - j : FAST_GEMM_F32_NR;
            int nr_esz = nr * esz;
            bool partial = (bool)((mr < FAST_GEMM_F32_MR) | (nr < FAST_GEMM_F32_NR));
            if (partial) {
                memset(tempC, 0, sizeof(tempC));
                cptr = (char *)tempC;
                ldc = FAST_GEMM_F32_NR;
                for(int p = 0; p < mr; p++)
                    memcpy(cptr + p * (ldc * esz), cptr0 + p * ldc0_esz, nr_esz);
            }
            fast_gemm_f32(k, packed_A + i * k * esz, packed_B + j * k * esz, cptr, ldc, alpha);

            if (partial) {
                for(int p = 0; p < mr; p++)
                    memcpy(cptr0 + p * ldc0_esz, cptr + p * (ldc * esz), nr_esz);
            }
        }
    }
}

void fastGemmKernel(size_t M, size_t N, size_t K,
                    float alpha, const char *A, size_t lda0, size_t lda1,
                    const char *B, size_t ldb0, size_t ldb1,
                    float beta, char *C, size_t ldc, size_t esz, bool multi_thread) {
    size_t GEMM_MC = FAST_GEMM_F32_MC,
        GEMM_NC = FAST_GEMM_F32_NC,
        GEMM_MR = FAST_GEMM_F32_MR,
        GEMM_NR = FAST_GEMM_F32_NR;

    size_t MC = (((GEMM_MC < M ? GEMM_MC : M) + GEMM_MR - 1) / GEMM_MR) * GEMM_MR;
    size_t NC = (((GEMM_NC < N ? GEMM_NC : N) + GEMM_NR - 1) / GEMM_NR) * GEMM_NR;
    size_t KC = FAST_GEMM_STORAGE / ((MC + NC) * esz);
    KC = KC > 8 ? KC : 8;
    KC = KC < K ? KC : K;

    size_t buff_size = KC * (MC + NC) * esz;
    bool use_stackbuff = buff_size <= FAST_GEMM_MAX_STACKBUF;
    size_t m_tiles = (M + MC - 1) / MC;
    size_t n_tiles = (N + NC - 1) / NC;
    size_t total_tiles = m_tiles * n_tiles;

    auto fn = [&](const Range &r) {
        char* packed_a = (char*)(use_stackbuff ? alloca(buff_size) : malloc(buff_size));
        char* packed_b = packed_a + KC * MC * esz;
        size_t start = r.start;
        size_t end = r.end;

        for (size_t tile_idx = start; tile_idx < end; tile_idx++) {
            size_t i0 = (tile_idx / n_tiles) * MC;
            size_t j0 = (tile_idx % n_tiles) * NC;
            size_t mc = M - i0 < MC ? M - i0 : MC;
            size_t nc = N - j0 < NC ? N - j0 : NC;
            size_t ldc_block = ldc;
            char* c_block = C + (i0 * ldc + j0) * esz;

            if (beta == 0.f) {
                for(size_t i = 0; i < mc; i++)
                    memset(c_block + i * ldc_block * esz, 0, nc * esz);
            } else if (beta != 1.f) {
                for(size_t i = 0; i < mc; i++) {
                    float* c_i = (float*)c_block + i * ldc_block;
                    for(size_t j = 0; j < nc; j++)
                        c_i[j] *= beta;
                }
            }

            for(size_t k0 = 0; k0 < K; k0 += KC)
            {
                size_t kc = K - k0 < KC ? K - k0 : KC;
                fast_gemm_pack8_f32(mc, kc, A + (i0 * lda0 + k0 * lda1) * esz, lda0, lda1, packed_a);
                fast_gemm_pack12_f32(nc, kc, B + (k0 * ldb0 + j0 * ldb1) * esz, ldb1, ldb0, packed_b);
                fast_gemm_macro_kernel(mc, nc, kc, packed_a, packed_b, alpha, c_block, ldc_block, esz);
            }
        }

        if (!use_stackbuff) {
            free(packed_a);
        }
    };

    if (multi_thread) {
        int cost_per_thread = static_cast<int>((K / KC) * (MC / GEMM_MR) * (NC / GEMM_NR));
        double nstripes = (size_t)total_tiles * cost_per_thread * (1 / 1024.0);
        parallel_for_(Range(0, total_tiles), fn, nstripes);
    } else {
        fn(Range(0, total_tiles));
    }
}

void fastGemmKernel(size_t M, size_t N, size_t K,
                    float alpha, const char *A, size_t lda0, size_t lda1,
                    const char *packed_B, float beta, char *C, size_t ldc, size_t esz, bool multi_thread) {
    size_t GEMM_MC = FAST_GEMM_F32_MC,
        GEMM_NC = FAST_GEMM_F32_NC,
        GEMM_MR = FAST_GEMM_F32_MR,
        GEMM_NR = FAST_GEMM_F32_NR;

    size_t MC = (((GEMM_MC < M ? GEMM_MC : M) + GEMM_MR - 1) / GEMM_MR) * GEMM_MR;
    size_t NC = (((GEMM_NC < N ? GEMM_NC : N) + GEMM_NR - 1) / GEMM_NR) * GEMM_NR;
    size_t KC = std::min(static_cast<size_t>(FAST_GEMM_F32_PACKED_STRIDE_K), K);

    size_t buff_size = KC * MC * esz;
    bool use_stackbuff = buff_size <= FAST_GEMM_MAX_STACKBUF;
    size_t m_tiles = (M + MC - 1) / MC;
    size_t n_tiles = (N + NC - 1) / NC;
    size_t total_tiles = m_tiles * n_tiles;

    auto fn = [&](const Range &r) {
        char* packed_a = (char*)(use_stackbuff ? alloca(buff_size) : malloc(buff_size)); // TODO: use AutoBuffer
        const char *packed_b_ = packed_B;
        size_t start = r.start;
        size_t end = r.end;

        for (size_t tile_idx = start; tile_idx < end; tile_idx++) {
            size_t i0 = (tile_idx / n_tiles) * MC;
            size_t j0 = (tile_idx % n_tiles) * NC;
            size_t mc = M - i0 < MC ? M - i0 : MC;
            size_t nc = N - j0 < NC ? N - j0 : NC;
            size_t ldc_block = ldc;
            char* c_block = C + (i0 * ldc + j0) * esz;
            packed_b_ = packed_B + j0 * K * esz;

            if (beta == 0.f) {
                for(int i = 0; i < mc; i++)
                    memset(c_block + i * ldc_block * esz, 0, nc * esz);
            } else if (beta != 1.f) {
                for(int i = 0; i < mc; i++) {
                    float* c_i = (float*)c_block + i * ldc_block;
                    for(int j = 0; j < nc; j++)
                        c_i[j] *= beta;
                }
            }

            size_t _nc = static_cast<size_t>((nc + GEMM_NR - 1) / GEMM_NR) * GEMM_NR * esz;
            for(size_t k0 = 0; k0 < K; k0 += KC)
            {
                size_t kc = K - k0 < KC ? K - k0 : KC;
                fast_gemm_pack8_f32(mc, kc, A + (i0 * lda0 + k0 * lda1) * esz, lda0, lda1, packed_a);
                fast_gemm_macro_kernel(mc, nc, kc, packed_a, packed_b_, alpha, c_block, ldc_block, esz);
                packed_b_ += _nc * kc;
            }
        }

        if (!use_stackbuff) {
            free(packed_a);
        }
    };

    if (multi_thread) {
        int cost_per_thread = static_cast<int>((K / KC) * (MC / GEMM_MR) * (NC / GEMM_NR));
        double nstripes = (size_t)total_tiles * cost_per_thread * (1 / 1024.0);
        parallel_for_(Range(0, total_tiles), fn, nstripes);
    } else {
        fn(Range(0, total_tiles));
    }
}

void fastGemmBatchKernel(size_t batch, const size_t *A_offsets, const size_t *B_offsets, const size_t *C_offsets,
                         size_t M, size_t N, size_t K, float alpha, const char *A, size_t lda0, size_t lda1,
                         const char *B, size_t ldb0, size_t ldb1, float beta, char *C, size_t ldc, size_t esz) {
    size_t GEMM_MC = FAST_GEMM_F32_MC,
        GEMM_NC = FAST_GEMM_F32_NC,
        GEMM_MR = FAST_GEMM_F32_MR,
        GEMM_NR = FAST_GEMM_F32_NR;

    size_t MC = (((GEMM_MC < M ? GEMM_MC : M) + GEMM_MR - 1) / GEMM_MR) * GEMM_MR;
    size_t NC = (((GEMM_NC < N ? GEMM_NC : N) + GEMM_NR - 1) / GEMM_NR) * GEMM_NR;
    size_t KC = std::min(static_cast<size_t>(FAST_GEMM_F32_PACKED_STRIDE_K), K);

    size_t buff_size = KC * (MC + NC) * esz;
    bool use_stackbuff = buff_size <= FAST_GEMM_MAX_STACKBUF;
    size_t m_tiles = (M + MC - 1) / MC;
    size_t n_tiles = (N + NC - 1) / NC;
    size_t total_tiles = m_tiles * n_tiles;

    auto fn = [&](const Range &r) {
        char* packed_a = (char*)(use_stackbuff ? alloca(buff_size) : malloc(buff_size));
        char* packed_b = packed_a + KC * MC * esz;
        size_t start = r.start;
        size_t end = r.end;

        for (size_t tile_idx = start; tile_idx < end; tile_idx++) {
            const size_t batch_index = tile_idx / total_tiles;
            const size_t m_tiles_index = (tile_idx - batch_index * total_tiles) / n_tiles;
            const size_t n_tiles_index = tile_idx % n_tiles;

            size_t i0 = m_tiles_index * MC;
            size_t j0 = n_tiles_index * NC;
            size_t mc = M - i0 < MC ? M - i0 : MC;
            size_t nc = N - j0 < NC ? N - j0 : NC;
            size_t ldc_block = ldc;
            const char *a_block = A + A_offsets[batch_index] * esz;
            const char *b_block = B + B_offsets[batch_index] * esz;
            char* c_block = C + C_offsets[batch_index] * esz + (i0 * ldc + j0) * esz;

            if (beta == 0.f) {
                for(int i = 0; i < mc; i++)
                    memset(c_block + i * ldc_block * esz, 0, nc * esz);
            } else if (beta != 1.f) {
                for(int i = 0; i < mc; i++) {
                    float* c_i = (float*)c_block + i * ldc_block;
                    for(int j = 0; j < nc; j++)
                        c_i[j] *= beta;
                }
            }

            for(int k0 = 0; k0 < K; k0 += KC)
            {
                int kc = K - k0 < KC ? K - k0 : KC;
                // pack a
                fast_gemm_pack8_f32(mc, kc, a_block + (i0 * lda0 + k0 * lda1) * esz, lda0, lda1, packed_a);

                // pack b
                fast_gemm_pack12_f32(nc, kc, b_block + (k0 * ldb0 + j0 * ldb1) * esz, ldb1, ldb0, packed_b);

                // run kernel
                fast_gemm_macro_kernel(mc, nc, kc, packed_a, packed_b, alpha, c_block, ldc_block, esz);
            }
        }

        if (!use_stackbuff) {
            free(packed_a);
        }
    };

    int total = batch * total_tiles;
    int cost_per_thread = static_cast<int>((K / KC) * (MC / GEMM_MR) * (NC / GEMM_NR));
    double nstripes = (size_t)total * cost_per_thread * (1 / 1024.0);
    parallel_for_(Range(0, total), fn, nstripes);
}

void fastGemmBatchKernel(size_t batch, const size_t *A_offsets, const size_t *B_offsets, const size_t *C_offsets,
                         size_t M, size_t N, size_t K, float alpha, const char *A, size_t lda0, size_t lda1,
                         const char *packed_B, float beta, char *C, size_t ldc, size_t esz) {
    size_t GEMM_MC = FAST_GEMM_F32_MC,
        GEMM_NC = FAST_GEMM_F32_NC,
        GEMM_MR = FAST_GEMM_F32_MR,
        GEMM_NR = FAST_GEMM_F32_NR;

    size_t MC = (((GEMM_MC < M ? GEMM_MC : M) + GEMM_MR - 1) / GEMM_MR) * GEMM_MR;
    size_t NC = (((GEMM_NC < N ? GEMM_NC : N) + GEMM_NR - 1) / GEMM_NR) * GEMM_NR;
    size_t KC = std::min(static_cast<size_t>(FAST_GEMM_F32_PACKED_STRIDE_K), K);

    size_t buff_size = KC * MC * esz;
    bool use_stackbuff = buff_size <= FAST_GEMM_MAX_STACKBUF;
    size_t m_tiles = (M + MC - 1) / MC;
    size_t n_tiles = (N + NC - 1) / NC;
    size_t total_tiles = m_tiles * n_tiles;

    auto fn = [&](const Range &r) {
        char* packed_a = (char*)(use_stackbuff ? alloca(buff_size) : malloc(buff_size));
        const char *packed_b = packed_B;
        size_t start = r.start;
        size_t end = r.end;

        for (size_t tile_idx = start; tile_idx < end; tile_idx++) {
            const size_t batch_index = tile_idx / total_tiles;
            const size_t m_tiles_index = (tile_idx - batch_index * total_tiles) / n_tiles;
            const size_t n_tiles_index = tile_idx % n_tiles;

            size_t i0 = m_tiles_index * MC;
            size_t j0 = n_tiles_index * NC;
            size_t mc = M - i0 < MC ? M - i0 : MC;
            size_t nc = N - j0 < NC ? N - j0 : NC;
            size_t ldc_block = ldc;

            const char *a_block = A + A_offsets[batch_index] * esz;
            packed_b = packed_B + B_offsets[batch_index] * esz + j0 * K * esz;
            char* c_block = C + C_offsets[batch_index] * esz + (i0 * ldc + j0) * esz;

            if (beta == 0.f) {
                for(int i = 0; i < mc; i++)
                    memset(c_block + i * ldc_block * esz, 0, nc * esz);
            } else if (beta != 1.f) {
                for(int i = 0; i < mc; i++) {
                    float* c_i = (float*)c_block + i * ldc_block;
                    for(int j = 0; j < nc; j++)
                        c_i[j] *= beta;
                }
            }

            int _nc = static_cast<int>((nc + GEMM_NR - 1) / GEMM_NR) * GEMM_NR * esz;
            for(int k0 = 0; k0 < K; k0 += KC)
            {
                int kc = K - k0 < KC ? K - k0 : KC;
                // pack a
                size_t step_a =  (i0 * lda0 + k0 * lda1) * esz;
                fast_gemm_pack8_f32(mc, kc, a_block + step_a, lda0, lda1, packed_a);

                // run kernel
                fast_gemm_macro_kernel(mc, nc, kc, packed_a, packed_b, alpha, c_block, ldc_block, esz);
                packed_b += _nc * kc;
            }
        }

        if (!use_stackbuff) {
            free(packed_a);
        }
    };

    int total = batch * total_tiles;
    int cost_per_thread = static_cast<int>((K / KC) * (MC / GEMM_MR) * (NC / GEMM_NR));
    double nstripes = (size_t)total * cost_per_thread * (1 / 1024.0);
    parallel_for_(Range(0, total), fn, nstripes);
}



// specially for attention
// compute QK, supports KV Cache
// pages in K are always of shape [B, N_kv, T_s, D]
// tot. seq len T = T_s * S
void pagedAttnQKGemmKernel(
    const char *Q, const std::vector<const char *> &K, char *A,
    size_t B, size_t T_q, size_t Nq, size_t N_k, size_t T_s, size_t D, size_t T_k,
    float sm_scale, size_t esz, bool isQ3d
) {
    size_t GEMM_MC = static_cast<size_t>(FAST_GEMM_F32_MC),
        GEMM_NC = static_cast<size_t>(FAST_GEMM_F32_NC),
        GEMM_MR = static_cast<size_t>(FAST_GEMM_F32_MR),
        GEMM_NR = static_cast<size_t>(FAST_GEMM_F32_NR);

    size_t MC = (((GEMM_MC < T_q ? GEMM_MC : T_q) + GEMM_MR - 1) / GEMM_MR) * GEMM_MR;
    size_t NC = (((GEMM_NC < T_s ? GEMM_NC : T_s) + GEMM_NR - 1) / GEMM_NR) * GEMM_NR;
    size_t KC = std::min( static_cast<size_t>(FAST_GEMM_F32_PACKED_STRIDE_K), D);

    size_t buff_size = KC * MC * esz;

    const size_t m_tiles = (T_q + MC - 1) / MC;
    const size_t n_tiles = (T_s + NC - 1) / NC;
    const size_t tiles_per_mat = m_tiles * n_tiles;
    const size_t S = K.size();
    const size_t T = S * T_s;
    const size_t T_r = T_s - (T - T_k);
    const int n_kq_groups = Nq / N_k;
    size_t batch = Nq * B;
    // batch = B x N_q
    int total = S *  batch * tiles_per_mat;

    size_t packed_stride = fastGemmPackBSize(T_s, D);

    auto fn = [&](const Range &r) {
        cv::AutoBuffer<char, FAST_GEMM_MAX_STACKBUF> packed_q_buff;
        packed_q_buff.allocate(buff_size);
        char*packed_q = packed_q_buff.data();

        size_t start = r.start;
        size_t end = r.end;
        size_t ldq0 = isQ3d ? Nq * D : D;

        for (size_t tile_idx = start; tile_idx < end; tile_idx++) {
            size_t idx = tile_idx / tiles_per_mat;
            size_t b = idx / (Nq * S);
            size_t nq = (idx - b * Nq * S) / S;
            size_t n_k = nq / n_kq_groups;
            size_t s = (idx - b * Nq * S) % S;

            const size_t m_tiles_index = (tile_idx - idx * tiles_per_mat) / n_tiles;
            const size_t n_tiles_index = tile_idx % n_tiles;

            size_t i0 = m_tiles_index * MC;
            size_t j0 = n_tiles_index * NC;
            size_t mc = T_q - i0 < MC ? T_q - i0 : MC;
            size_t nc = T_s - j0 < NC ? T_s - j0 : NC;

            size_t rc = nc;
            if (s == S - 1) {
                if (j0 >= T_r) continue; // Completely out of bounds, skip this tile
                rc = std::min(nc, T_r - j0);
            }

            size_t q_offset = b * Nq * T_q * D              +
                              (isQ3d ? nq * D : nq * T_q * D);
            const char *q_block = Q + q_offset * esz;

            size_t k_offset = b * N_k * packed_stride +
                              n_k * packed_stride     +
                              j0 * D;
            const char *k_block = (const char *)K[s] + k_offset * esz;

            // save result to A[b, n_q, : , T_s * s : T_s * (s + 1)]
            const size_t a_offset = b * Nq * T_q * T_k +
                                    nq * T_q * T_k     +
                                    T_s * s            +
                                    i0 * T_k + j0;
            char* a_block = A + a_offset  * esz;

            for(size_t i = 0; i < mc; i++) {
                memset(a_block + i * T_k * esz, 0, rc * esz);
            }

            int _nc = static_cast<int>((nc + GEMM_NR - 1) / GEMM_NR) * GEMM_NR * esz;
            for(int k0 = 0; k0 < (int)D; k0 += (int)KC)
            {
                int kc = D - k0 < (int)KC ? (int)D - k0 : (int)KC;
                // pack q
                size_t step_q = (i0 * ldq0 + k0) * esz;
                fast_gemm_pack8_f32(mc, kc, q_block + step_q, ldq0, 1, packed_q);
                // run kernel
                fast_gemm_macro_kernel(mc, rc, kc, packed_q, k_block, sm_scale, a_block, T_k, esz);
                k_block += _nc * kc;
            }
        }

    };


    int cost_per_thread = static_cast<int>((D / KC) * (MC / GEMM_MR) * (NC / GEMM_NR));
    double nstripes = (size_t)total * cost_per_thread * (1 / 1024.0);
    parallel_for_(Range(0, total), fn, nstripes);
}



// specially for attention
// compute QK, supports KV Cache
// A is of shape [B, N_q, T_q, T_s * S]
// pages in K are always of shape [B, N_kv, T_s, D]
// tot. seq len T = T_s * S
void pagedAttnAVGemmKernel(
    const char* A, const std::vector<const char *> &V, char*Out,
    size_t B, size_t T_a, size_t Nq, size_t N_k, size_t T_s, size_t D, size_t T_v,
    size_t esz, bool canonical_layout, size_t packed_stride
) {

    size_t GEMM_MC = static_cast<size_t>(FAST_GEMM_F32_MC),
        GEMM_NC = static_cast<size_t>(FAST_GEMM_F32_NC),
        GEMM_MR = static_cast<size_t>(FAST_GEMM_F32_MR),
        GEMM_NR = static_cast<size_t>(FAST_GEMM_F32_NR);

    size_t MC = (((GEMM_MC < T_a ? GEMM_MC : T_a) + GEMM_MR - 1) / GEMM_MR) * GEMM_MR;
    size_t NC = (((GEMM_NC < D ? GEMM_NC : D) + GEMM_NR - 1) / GEMM_NR) * GEMM_NR;
    size_t KC = std::min( static_cast<size_t>(FAST_GEMM_F32_PACKED_STRIDE_K), T_v);

    size_t buff_size = KC * MC * esz;

    const size_t m_tiles = (T_a + MC - 1) / MC;
    const size_t n_tiles = (D + NC - 1) / NC;
    const size_t tiles_per_mat = m_tiles * n_tiles;
    const int n_kq_groups = Nq / N_k;
    size_t batch = Nq * B;
    int total = batch * tiles_per_mat;

    auto fn = [&](const Range &r) {
        cv::AutoBuffer<char, FAST_GEMM_MAX_STACKBUF> packed_a_buff;
        packed_a_buff.allocate(buff_size);
        char* packed_a = packed_a_buff.data();

        cv::AutoBuffer<char, FAST_GEMM_MAX_STACKBUF> repacked_v_buff;
        repacked_v_buff.allocate(NC * T_s * esz);
        char* repacked_v = repacked_v_buff.data();

        size_t start = r.start;
        size_t end = r.end;
        size_t ldc0 = canonical_layout ? Nq * D : D;

        for (size_t tile_idx = start; tile_idx < end; tile_idx++) {
            size_t idx = tile_idx / tiles_per_mat;
            size_t b = idx / Nq;
            size_t nq = idx % Nq;
            size_t n_k = nq / n_kq_groups;

            size_t m_tiles_index = (tile_idx - idx * tiles_per_mat) / n_tiles;
            size_t n_tiles_index = tile_idx % n_tiles;

            size_t i0 = m_tiles_index * MC;
            size_t j0 = n_tiles_index * NC;

            size_t mc = T_a - i0 < MC ? T_a - i0 : MC;
            size_t nc = D - j0 < NC ? D - j0 : NC;

            const size_t a_offset = b * Nq * T_a * T_v +
                                    nq * T_a * T_v     +
                                    i0 * T_v;
            const char*a_block    = A + a_offset * esz;

            // start at the 0th row
            // column offset is determined according to packed layout
            size_t v_offset_base = b * N_k * packed_stride  +
                                   n_k * packed_stride      +
                                   n_tiles_index * T_s * NC;

            size_t o_offset = b * Nq * T_a * D;
            if (canonical_layout)
                o_offset += i0 * Nq * D + nq * D + j0;
            else
                o_offset += nq * T_a * D + i0 * D + j0;
            char* out_block = Out + o_offset * esz;

            for(size_t i = 0; i < mc; i++) {
                memset(out_block + i * ldc0 * esz, 0, nc * esz);
            }

            // int _nc = static_cast<int>((nc + GEMM_NR - 1) / GEMM_NR) * GEMM_NR * esz;

            for(int k0 = 0; k0 < (int)T_v; )
            {
                size_t sk = k0 / T_s; // which page
                size_t k = k0 % T_s;
                int kc = std::min((int)KC, (int)T_v - k0);
                kc = std::min(kc, (int)T_s - (int)k);

                size_t v_offset = v_offset_base * esz + k * GEMM_NR * esz;
                const char *v_block = V[sk] + v_offset;

                // pack a
                fast_gemm_pack8_f32(mc, kc, a_block + k0 * esz, T_v, 1, packed_a);

                const char* v_block_to_use = v_block;
                if (kc < (int)T_s) {
                    for (size_t j = 0; j < nc; j += GEMM_NR) {
                        const char *src_panel = v_block + j * T_s * esz;
                        char *dst_panel = repacked_v + j * kc * esz;
                        memcpy(dst_panel, src_panel, kc * GEMM_NR * esz);
                    }
                    v_block_to_use = repacked_v;
                }

                // run kernel
                fast_gemm_macro_kernel(mc, nc, kc, packed_a, v_block_to_use, 1.f, out_block, ldc0, esz);
                k0 += kc;
            }
        }

    };

    int cost_per_thread = static_cast<int>((T_v / KC) * (MC / GEMM_MR) * (NC / GEMM_NR));
    double nstripes = (size_t)total * cost_per_thread * (1 / 1024.0);
    parallel_for_(Range(0, total), fn, nstripes);
}


}}} // cv::dnn::cpu_baseline

#undef FAST_GEMM_STORAGE
#undef FAST_GEMM_MAX_STACKBUF
#ifdef FAST_GEMM_F32_MC
#undef FAST_GEMM_F32_MC
#endif
#ifdef FAST_GEMM_F32_NC
#undef FAST_GEMM_F32_NC
#endif
#ifdef FAST_GEMM_F32_MR
#undef FAST_GEMM_F32_MR
#endif
#ifdef FAST_GEMM_F32_NR
#undef FAST_GEMM_F32_NR
#endif
#ifdef FAST_GEMM_F32_PACKED_STRIDE_K
#undef FAST_GEMM_F32_PACKED_STRIDE_K
#endif
#undef FAST_GEMM_IMPLEMENT_PACK
#undef FAST_GEMM_LOAD_TO_BUF_8
#undef FAST_GEMM_LOAD_TO_BUF_BORDERS_8
#undef FAST_GEMM_LOAD_TO_BUF_12
#undef FAST_GEMM_LOAD_TO_BUF_BORDERS_12
#undef FAST_GEMM_PACK_COPY
#undef FAST_GEMM_PACK_f32_8
#undef FAST_GEMM_PACK_f32_12
